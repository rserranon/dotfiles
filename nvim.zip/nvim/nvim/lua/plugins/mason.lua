return {
  "williamboman/mason.nvim",
}
